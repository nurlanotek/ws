package kg.cs.mobileapp.service;

import kg.cs.mobileapp.shared.dto.UserDto;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    public UserDto createUser(UserDto userDto);
}
